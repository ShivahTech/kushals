<?php 
    require "common/config.php";

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

if($_POST['data_from']=='user'){
        $first_name = $_POST['f_name'];
        $last_name = $_POST['l_name'];
        $ph_no = $_POST['phone'];
        $email = $_POST['email'];
        $message = $_POST['message'];

        //insert data 
        $insert = "INSERT INTO user(`id`, `f_name`, `l_name`, `ph_no`, `email`, `message`)VALUES('','$first_name','$last_name','$ph_no','$email','$message')";

        $query = mysqli_query($conn,$insert);

        if($query){
            require 'PHPMailer/PHPMailer/src/Exception.php';
            require 'PHPMailer/PHPMailer/src/PHPMailer.php';
            require 'PHPMailer/PHPMailer/src/SMTP.php';

            //Create an instance; passing `true` enables exceptions
            $mail = new PHPMailer(true);

            try {
                //Server settings
               // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                $mail->isSMTP();                                            //Send using SMTP
                $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                $mail->Username   = 'vishalkumar11a4717@gmail.com';                     //SMTP username
                $mail->Password   = 'edlo ishu kvrb ecar';                               //SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

                //Recipients
                $mail->setFrom('vishalkumar11a4717@gmail.com', 'AMB-Logistic');
                $mail->addAddress('krishanjnr97@gmail.com');     //Add a recipient
                $mail->addReplyTo('vishalkumar11a4717@gmail.com', 'Information');

                //Content
                    $mail->isHTML(true);                                  //Set email format to HTML
                    $mail->Subject = 'User Register';
                    $mail->Body    = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="UTF-8" />
                        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
                        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                        <title>AMB Logistic - Login Notification</title>
                        <style>
                        /* Reset some default styles */
                        body,
                        html {
                            margin: 0;
                            padding: 0;
                            font-family: Arial, sans-serif;
                        }
                    
                        /* Container for the email content */
                        .container {
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }
                    
                        /* Styles for the main content area */
                        .content {
                            padding: 20px;
                            background-color: #f5f5f5;
                            border-radius: 10px;
                        }
                        span.text-blue {
                            color: #0273bf;
                        }
                        /* Styles for the heading */
                        .heading {
                            font-size: 31px;
                            margin-bottom: 20px;
                            text-align: center;
                            font-weight: 600;
                        }
                    
                        /* Styles for the paragraph */
                        .paragraph {
                            font-size: 16px;
                            margin-bottom: 20px;
                        }
                    
                        /* Button styles */
                        .button {
                            display: inline-block;
                            padding: 10px 20px;
                            font-size: 16px;
                            text-align: center;
                            text-decoration: none;
                            border-radius: 5px;
                            color: #fff;
                            background-color: #007bffce;
                        }
                    
                        /* Table styles */
                        table {
                            width: 100%;
                            margin-bottom: 20px;
                            border-collapse: collapse;
                        }
                        span.text-red {
                            color: #c1292e;
                        }
                        th,
                        td {
                            padding: 10px;
                            border-bottom: 1px solid #ddd;
                            text-align: left;
                        }
                    
                        th {
                            background-color: #f1f1f1;
                        }
                        </style>
                    </head>
                    
                    <body>
                        <div class="container">
                            <div class="content">
                                <div class="paragraph">
                                    <img class="img-fluid" src="https://images.crunchbase.com/image/upload/c_lpad,h_256,w_256,f_auto,q_auto:eco,dpr_1/emqp92w0yczvqegtccjj" />
                                </div>
                                <div class="heading">
                                    Welcome to <span class="text-blue">A</span
                                    ><span class="text-red">M</span><span class="text-blue">B</span>
                                    <span class="text-red">Log</span><span class="text-blue">istic</span>
                                </div>
                                <div>
                                    <table class="table table-stripped">
                                    <tr>
                                        <th>User</th>
                                        <th>Mail</th>
                                    </tr>
                                    <tr>
                                    <td>'.$_POST["f_name"].'</td>
                                    <td>'.$_POST["email"].'</td>
                                    </tr>
                                    </table>
                                </div>
                                <div>
                                    <a href="#" class="button">Visit AMB Logistic</a>
                                </div>
                            </div>
                        </div>
                    </body>
                    </html>';
                
                $mail->send();
                echo 'Data Submitted';
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        }
        else{
            $error = "Error:". $conn;
        }
}else
if($_POST['data_from']=='customer'){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $pickup_city = $_POST['p_city'];
    $pickup_state = $_POST['p_state'];
    $pickup_zip = $_POST['p_zip'];
    $delivery_city = $_POST['d_city'];
    $delivery_state = $_POST['d_state'];
    $delivery_zip = $_POST['d_zip'];

    //insert data 
    $insert = "INSERT INTO customer
    (`id`, `name`, `email`, `number`, `p_city`, `p_state`,`p_zip`, `d_city`, `d_state`,`d_zip`)VALUES('','$name','$email','$number','$pickup_city','$pickup_state','$pickup_zip','$delivery_city','$delivery_state','$delivery_zip')";

    $query = mysqli_query($conn,$insert);

    if($query){
        require 'PHPMailer/PHPMailer/src/Exception.php';
        require 'PHPMailer/PHPMailer/src/PHPMailer.php';
        require 'PHPMailer/PHPMailer/src/SMTP.php';

        //Create an instance; passing `true` enables exceptions
        $mail = new PHPMailer(true);

        try {
            //Server settings
            // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'vishalkumar11a4717@gmail.com';                     //SMTP username
            $mail->Password   = 'edlo ishu kvrb ecar';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

            //Recipients
            $mail->setFrom('vishalkumar11a4717@gmail.com', 'AMB-Logistic');
            $mail->addAddress('krishanjnr97@gmail.com');     //Add a recipient
            $mail->addReplyTo('vishalkumar11a4717@gmail.com', 'Information');

            //Content
                $mail->isHTML(true);                                  //Set email format to HTML
                $mail->Subject = 'Customer Query';
                $mail->Body    = '<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8" />
                    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
                    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                    <title>AMB Logistic - Login Notification</title>
                    <style>
                    /* Reset some default styles */
                    body,
                    html {
                        margin: 0;
                        padding: 0;
                        font-family: Arial, sans-serif;
                    }
                
                    /* Container for the email content */
                    .container {
                        max-width: 600px;
                        margin: 0 auto;
                        padding: 20px;
                    }
                
                    /* Styles for the main content area */
                    .content {
                        padding: 20px;
                        background-color: #f5f5f5;
                        border-radius: 10px;
                    }
                    span.text-blue {
                        color: #0273bf;
                    }
                    /* Styles for the heading */
                    .heading {
                        font-size: 31px;
                        margin-bottom: 20px;
                        text-align: center;
                        font-weight: 600;
                    }
                
                    /* Styles for the paragraph */
                    .paragraph {
                        font-size: 16px;
                        margin-bottom: 20px;
                    }
                
                    /* Button styles */
                    .button {
                        display: inline-block;
                        padding: 10px 20px;
                        font-size: 16px;
                        text-align: center;
                        text-decoration: none;
                        border-radius: 5px;
                        color: #fff;
                        background-color: #007bffce;
                    }
                
                    /* Table styles */
                    table {
                        width: 100%;
                        margin-bottom: 20px;
                        border-collapse: collapse;
                    }
                    span.text-red {
                        color: #c1292e;
                    }
                    th,
                    td {
                        padding: 10px;
                        border-bottom: 1px solid #ddd;
                        text-align: left;
                    }
                
                    th {
                        background-color: #f1f1f1;
                    }
                    </style>
                </head>
                
                <body>
                    <div class="container">
                        <div class="content">
                            <div class="paragraph">
                                <img class="img-fluid" src="https://images.crunchbase.com/image/upload/c_lpad,h_256,w_256,f_auto,q_auto:eco,dpr_1/emqp92w0yczvqegtccjj" />
                            </div>
                            <div class="heading">
                                Welcome to <span class="text-blue">A</span
                                ><span class="text-red">M</span><span class="text-blue">B</span>
                                <span class="text-red">Log</span><span class="text-blue">istic</span>
                            </div>
                            <div>
                                <table class="table table-stripped">
                                <tr>
                                    <th>User</th>
                                    <th>Mail</th>
                                </tr>
                                <tr>
                                <td>'.$_POST["name"].'</td>
                                <td>'.$_POST["email"].'</td>
                                </tr>
                                </table>
                            </div>
                            <div>
                                <a href="#" class="button">Visit AMB Logistic</a>
                            </div>
                        </div>
                    </div>
                </body>
                </html>';
            
        $mail->send();
        echo 'Data Submitted';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }
    else{
        $error = "Error:". $conn;
    }
}
else
if($_POST['data_from']=='contact'){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $message = $_POST['message'];

        //insert data 
        $insert = "INSERT INTO contact(`id`, `name`, `email`, `message`)VALUES('','$name','$email','$message')";

        $query = mysqli_query($conn,$insert);

        if($query){
            require 'PHPMailer/PHPMailer/src/Exception.php';
            require 'PHPMailer/PHPMailer/src/PHPMailer.php';
            require 'PHPMailer/PHPMailer/src/SMTP.php';

            //Create an instance; passing `true` enables exceptions
            $mail = new PHPMailer(true);

            try {
                //Server settings
                // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                $mail->isSMTP();                                            //Send using SMTP
                $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                $mail->Username   = 'vishalkumar11a4717@gmail.com';                     //SMTP username
                $mail->Password   = 'edlo ishu kvrb ecar';                               //SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

                //Recipients
                $mail->setFrom('vishalkumar11a4717@gmail.com', 'AMB-Logistic');
                $mail->addAddress('krishanjnr97@gmail.com');     //Add a recipient
                $mail->addReplyTo('vishalkumar11a4717@gmail.com', 'Information');

                //Content
                    $mail->isHTML(true);                                  //Set email format to HTML
                    $mail->Subject = 'Contact Us Query';
                    $mail->Body    = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="UTF-8" />
                        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
                        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                        <title>AMB Logistic - Login Notification</title>
                        <style>
                        /* Reset some default styles */
                        body,
                        html {
                            margin: 0;
                            padding: 0;
                            font-family: Arial, sans-serif;
                        }
                    
                        /* Container for the email content */
                        .container {
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                        }
                    
                        /* Styles for the main content area */
                        .content {
                            padding: 20px;
                            background-color: #f5f5f5;
                            border-radius: 10px;
                        }
                        span.text-blue {
                            color: #0273bf;
                        }
                        /* Styles for the heading */
                        .heading {
                            font-size: 31px;
                            margin-bottom: 20px;
                            text-align: center;
                            font-weight: 600;
                        }
                    
                        /* Styles for the paragraph */
                        .paragraph {
                            font-size: 16px;
                            margin-bottom: 20px;
                        }
                    
                        /* Button styles */
                        .button {
                            display: inline-block;
                            padding: 10px 20px;
                            font-size: 16px;
                            text-align: center;
                            text-decoration: none;
                            border-radius: 5px;
                            color: #fff;
                            background-color: #007bffce;
                        }
                    
                        /* Table styles */
                        table {
                            width: 100%;
                            margin-bottom: 20px;
                            border-collapse: collapse;
                        }
                        span.text-red {
                            color: #c1292e;
                        }
                        th,
                        td {
                            padding: 10px;
                            border-bottom: 1px solid #ddd;
                            text-align: left;
                        }
                    
                        th {
                            background-color: #f1f1f1;
                        }
                        </style>
                    </head>
                    
                    <body>
                        <div class="container">
                            <div class="content">
                                <div class="paragraph">
                                    <img class="img-fluid" src="https://images.crunchbase.com/image/upload/c_lpad,h_256,w_256,f_auto,q_auto:eco,dpr_1/emqp92w0yczvqegtccjj" />
                                </div>
                                <div class="heading">
                                    Welcome to <span class="text-blue">A</span
                                    ><span class="text-red">M</span><span class="text-blue">B</span>
                                    <span class="text-red">Log</span><span class="text-blue">istic</span>
                                </div>
                                <div>
                                    <table class="table table-stripped">
                                    <tr>
                                        <th>User</th>
                                        <th>Mail</th>
                                    </tr>
                                    <tr>
                                    <td>'.$_POST["name"].'</td>
                                    <td>'.$_POST["email"].'</td>
                                    </tr>
                                    </table>
                                </div>
                                <div>
                                    <a href="#" class="button">Visit AMB Logistic</a>
                                </div>
                            </div>
                        </div>
                    </body>
                    </html>';
                $mail->send();
                echo 'Data Submitted';
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            } 
        }
        else{
            $error = "Error:". $conn;
        }
}    
?> 

