<?php
include("common/header.php");

?>
<section class="banner-section">
    <div class="container">
        <div class="row align-items-center vh-100"> 
            <div class="col-lg-9">
                <div class="banner-detail">
                    <h1>WE <span>
                            DELIVER
                        </span>
                        PERFECTION
                    </h1>
                    <p>
                        AMB Logistic provides contract warehousing and distribution services from modern facilities and
                        sophisticated warehouse management systems to provide integrated real-time inventory
                        management.
                    </p>
                    <div class="banner-btn ">
                        <a class="banner-link" href="services">
                            Services <i class="fa fa-angle-double-right ms-2" aria-hidden="true"></i>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- about-section -->
<section class="padding-top services-section">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-lg-6 text-center" >
                <div class="sub-heading">
                    <h2 class="heading-detail mx-2">
                        <svg class="svg-left svg-right me-2" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" width="33" height="21" viewBox="0 0 33 21">
                            <defs>

                                <filter id="left-h-filterct_heading-36d6b53" x="-0.125" y="-0.094" width="32.406"
                                    height="12" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <filter id="left-h-filter-2ct_heading-36d6b53" x="-10" y="14.594" width="29.656"
                                    height="6.406" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <linearGradient id="left-h-grad1ct_heading-36d6b53" x1="0%" y1="0%" x2="100%" y2="0%">
                                    <stop offset="0%" style="stop-color: #0273bf;stop-opacity:1"></stop>
                                    <stop offset="100%" style="stop-color: #026eb8;stop-opacity:1"></stop>
                                </linearGradient>
                            </defs>
                            <g>
                                <g style="fill: none; filter: url(#left-h-filterct_heading-36d6b53)">
                                    <path id="left-h-pathct_heading-36d6b53" class="h-cls-1"
                                        d="M-0.117,8.9H27.036s5.078-3.073,0-6.517"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-pathct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                                <g style="fill: none; filter: url(#left-h-filter-2ct_heading-36d6b53)">
                                    <path id="left-h-bgct_heading-36d6b53" class="h-cls-2"
                                        d="M-9.991,14.594H17.352s5.114,3.027,0,6.422"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-bgct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                            </g>
                        </svg> About Us
<svg class="svg-left ms-2" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" width="33" height="21" viewBox="0 0 33 21">
                            <defs>
                                <style>
                                .h-cls-1,
                                .h-cls-2 {
                                    fill: none;
                                    stroke-width: 3px;
                                    fill-rule: evenodd;
                                }

                                .h-cls-1 {
                                    filter: url(#filter);
                                }

                                .h-cls-2 {
                                    filter: url(#filter-2);
                                }
                                </style>
                                <filter id="left-h-filterct_heading-36d6b53" x="-0.125" y="-0.094" width="32.406"
                                    height="12" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <filter id="left-h-filter-2ct_heading-36d6b53" x="-10" y="14.594" width="29.656"
                                    height="6.406" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <linearGradient id="left-h-grad1ct_heading-36d6b53" x1="0%" y1="0%" x2="100%" y2="0%">
                                    <stop offset="0%" style="stop-color: #0273bf;stop-opacity:1"></stop>
                                    <stop offset="100%" style="stop-color: #026eb8;stop-opacity:1"></stop>
                                </linearGradient>
                            </defs>
                            <g>
                                <g style="fill: none; filter: url(#left-h-filterct_heading-36d6b53)">
                                    <path id="left-h-pathct_heading-36d6b53" class="h-cls-1"
                                        d="M-0.117,8.9H27.036s5.078-3.073,0-6.517"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-pathct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                                <g style="fill: none; filter: url(#left-h-filter-2ct_heading-36d6b53)">
                                    <path id="left-h-bgct_heading-36d6b53" class="h-cls-2"
                                        d="M-9.991,14.594H17.352s5.114,3.027,0,6.422"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-bgct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                            </g>
                        </svg>
                    </h2>
                </div>
            </div>
        </div>
        <!-- about-detail -->



    </div>
    </div>
</section>
<!-- end-about-section -->
<section class="about-area ptb-100">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-6" >

                <div class="about-img">
                    <img src="assets/images/about-img.jpg" alt="Image" class="img-fluid">
                    <div class="about-quatre">
                        <i class="fa fa-quote-left bx-tada" aria-hidden="true"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">

                <div class="about-content ml-30">
                    <span>About Us</span>
                    <h2>Reliable and express logistics and transport solutions That no waste your time!</h2>
                    <p class="mb-0">
                        We offer the most secured and cost-effective freight services in the industry. Our team
                        helps shippers manage their supply chains most efficiently, using our advanced technology
                        for the movement of goods.</p>
                </div>

            </div>
        </div>
    </div>
</section>
<!-- services-section -->

<section class="padding-top services-section">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-lg-6 text-center">
                <div class="sub-heading">
                    <h2 class="heading-detail mx-2">
                        <svg class="svg-left svg-right me-2" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" width="33" height="21" viewBox="0 0 33 21">
                            <defs>

                                <filter id="left-h-filterct_heading-36d6b53" x="-0.125" y="-0.094" width="32.406"
                                    height="12" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <filter id="left-h-filter-2ct_heading-36d6b53" x="-10" y="14.594" width="29.656"
                                    height="6.406" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <linearGradient id="left-h-grad1ct_heading-36d6b53" x1="0%" y1="0%" x2="100%" y2="0%">
                                    <stop offset="0%" style="stop-color: #0273bf;stop-opacity:1"></stop>
                                    <stop offset="100%" style="stop-color: #026eb8;stop-opacity:1"></stop>
                                </linearGradient>
                            </defs>
                            <g>
                                <g style="fill: none; filter: url(#left-h-filterct_heading-36d6b53)">
                                    <path id="left-h-pathct_heading-36d6b53" class="h-cls-1"
                                        d="M-0.117,8.9H27.036s5.078-3.073,0-6.517"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-pathct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                                <g style="fill: none; filter: url(#left-h-filter-2ct_heading-36d6b53)">
                                    <path id="left-h-bgct_heading-36d6b53" class="h-cls-2"
                                        d="M-9.991,14.594H17.352s5.114,3.027,0,6.422"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-bgct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                            </g>
                        </svg> Our Services<svg class="svg-left ms-2" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" width="33" height="21" viewBox="0 0 33 21">
                            <defs>
                                <style>
                                .h-cls-1,
                                .h-cls-2 {
                                    fill: none;
                                    stroke-width: 3px;
                                    fill-rule: evenodd;
                                }

                                .h-cls-1 {
                                    filter: url(#filter);
                                }

                                .h-cls-2 {
                                    filter: url(#filter-2);
                                }
                                </style>
                                <filter id="left-h-filterct_heading-36d6b53" x="-0.125" y="-0.094" width="32.406"
                                    height="12" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <filter id="left-h-filter-2ct_heading-36d6b53" x="-10" y="14.594" width="29.656"
                                    height="6.406" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <linearGradient id="left-h-grad1ct_heading-36d6b53" x1="0%" y1="0%" x2="100%" y2="0%">
                                    <stop offset="0%" style="stop-color: #0273bf;stop-opacity:1"></stop>
                                    <stop offset="100%" style="stop-color: #026eb8;stop-opacity:1"></stop>
                                </linearGradient>
                            </defs>
                            <g>
                                <g style="fill: none; filter: url(#left-h-filterct_heading-36d6b53)">
                                    <path id="left-h-pathct_heading-36d6b53" class="h-cls-1"
                                        d="M-0.117,8.9H27.036s5.078-3.073,0-6.517"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-pathct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                                <g style="fill: none; filter: url(#left-h-filter-2ct_heading-36d6b53)">
                                    <path id="left-h-bgct_heading-36d6b53" class="h-cls-2"
                                        d="M-9.991,14.594H17.352s5.114,3.027,0,6.422"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-bgct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                            </g>
                        </svg>
                    </h2>
                </div>
            </div>



        </div>
        <div class="row align-items-center justify-content-between">
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="">
                                        <img src="assets/images/ltl.png" class="img-fluid" />

                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    LTL</h4>
                                <div class="feature-details">
                                    Less than load is a shipping service for relatively small loads or quantities of
                                    freight - Between 150 and 15,000 pounds.


                                </div>
                            </div>
                            <div class="feature-btn one-btn">
                                <a href="services">
                                More Details
                                  </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="">
                                        <img src="assets/images/ftl.png" class="img-fluid"/>

                                    </a>

                                </div>
                                <h4 class="feature-title ">
                                    FTL</h4>
                                <div class="feature-details">
                                    In case you require a full truck to get your load shipped, FTL(Full Truckload) takes
                                    advantage of the entire volume of the vehicle which can weigh 20,000 pounds or more.


                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="services">
                                    More Details </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="">
                                        <img src="assets/images/ftb.png" class="img-fluid" />

                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    FLAT BED</h4>
                                <div class="feature-details">
                                    It has a flat carrier attached to it for carrying cargo wherein the flat trailer
                                    allows cargo to be loaded from the top as well as from the side. It can transport
                                    all kinds of loads.

                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="services">
                                    More Details </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 text-end ">
                <div class="services-btn">
                    <a href="#" class="custome-services-link">
                        Visit Services Page <i class="fa fa-angle-double-right ms-2" aria-hidden="true"></i>
                    </a>

                </div>

            </div>
        </div>

    </div>

</section>


<!-- end-services-section -->

<!-- 
    <section class="set-padding-top ">
        <div class="container">
            <div class="row align-items-center justify-content-center ">
                <div class="col-lg-6 text-center">
                    <div class="sub-heading">
                        <h2 class="heading-detail mx-2">
                            <svg class="svg-left svg-right me-2" xmlns="http://www.w3.org/2000/svg"
                                xmlns:xlink="http://www.w3.org/1999/xlink" width="33" height="21" viewBox="0 0 33 21">
                                <defs>

                                    <filter id="left-h-filterct_heading-36d6b53" x="-0.125" y="-0.094" width="32.406"
                                        height="12" filterUnits="userSpaceOnUse">
                                        <feFlood result="flood"></feFlood>
                                        <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                        <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                    </filter>
                                    <filter id="left-h-filter-2ct_heading-36d6b53" x="-10" y="14.594" width="29.656"
                                        height="6.406" filterUnits="userSpaceOnUse">
                                        <feFlood result="flood"></feFlood>
                                        <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                        <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                    </filter>
                                    <linearGradient id="left-h-grad1ct_heading-36d6b53" x1="0%" y1="0%" x2="100%"
                                        y2="0%">
                                        <stop offset="0%" style="stop-color: #e83d14;stop-opacity:1"></stop>
                                        <stop offset="100%" style="stop-color: #99280d;stop-opacity:1"></stop>
                                    </linearGradient>
                                </defs>
                                <g>
                                    <g style="fill: none; filter: url(#left-h-filterct_heading-36d6b53)">
                                        <path id="left-h-pathct_heading-36d6b53" class="h-cls-1"
                                            d="M-0.117,8.9H27.036s5.078-3.073,0-6.517"
                                            style="stroke: inherit; filter: none;"></path>
                                    </g>
                                    <use xlink:href="#left-h-pathct_heading-36d6b53"
                                        style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                    </use>
                                    <g style="fill: none; filter: url(#left-h-filter-2ct_heading-36d6b53)">
                                        <path id="left-h-bgct_heading-36d6b53" class="h-cls-2"
                                            d="M-9.991,14.594H17.352s5.114,3.027,0,6.422"
                                            style="stroke: inherit; filter: none;"></path>
                                    </g>
                                    <use xlink:href="#left-h-bgct_heading-36d6b53"
                                        style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                    </use>
                                </g>
                            </svg>Why Choose Us<svg class="svg-left ms-2" xmlns="http://www.w3.org/2000/svg"
                                xmlns:xlink="http://www.w3.org/1999/xlink" width="33" height="21" viewBox="0 0 33 21">
                                <defs>
                                    <style>
                                    .h-cls-1,
                                    .h-cls-2 {
                                        fill: none;
                                        stroke-width: 3px;
                                        fill-rule: evenodd;
                                    }

                                    .h-cls-1 {
                                        filter: url(#filter);
                                    }

                                    .h-cls-2 {
                                        filter: url(#filter-2);
                                    }
                                    </style>
                                    <filter id="left-h-filterct_heading-36d6b53" x="-0.125" y="-0.094" width="32.406"
                                        height="12" filterUnits="userSpaceOnUse">
                                        <feFlood result="flood"></feFlood>
                                        <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                        <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                    </filter>
                                    <filter id="left-h-filter-2ct_heading-36d6b53" x="-10" y="14.594" width="29.656"
                                        height="6.406" filterUnits="userSpaceOnUse">
                                        <feFlood result="flood"></feFlood>
                                        <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                        <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                    </filter>
                                    <linearGradient id="left-h-grad1ct_heading-36d6b53" x1="0%" y1="0%" x2="100%"
                                        y2="0%">
                                        <stop offset="0%" style="stop-color:#006cff;stop-opacity:1"></stop>
                                        <stop offset="100%" style="stop-color:#1227b8;stop-opacity:1"></stop>
                                    </linearGradient>
                                </defs>
                                <g>
                                    <g style="fill: none; filter: url(#left-h-filterct_heading-36d6b53)">
                                        <path id="left-h-pathct_heading-36d6b53" class="h-cls-1"
                                            d="M-0.117,8.9H27.036s5.078-3.073,0-6.517"
                                            style="stroke: inherit; filter: none;"></path>
                                    </g>
                                    <use xlink:href="#left-h-pathct_heading-36d6b53"
                                        style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                    </use>
                                    <g style="fill: none; filter: url(#left-h-filter-2ct_heading-36d6b53)">
                                        <path id="left-h-bgct_heading-36d6b53" class="h-cls-2"
                                            d="M-9.991,14.594H17.352s5.114,3.027,0,6.422"
                                            style="stroke: inherit; filter: none;"></path>
                                    </g>
                                    <use xlink:href="#left-h-bgct_heading-36d6b53"
                                        style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                    </use>
                                </g>
                            </svg>
                        </h2>
                    </div>
                </div>
            </div>


        </div>

        </div>
        <div class=" container-fluid px-0">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-7 col-12 ps-5">
                    <div>
                        <div class="about-content ml-30">

                            <h2 class="mb-0">We are best among them
                            </h2>

                        </div>
                    </div>
                    <div class="main-pills-section">
                        <div class="pills-section">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                                        data-bs-target="#home-tab-pane" type="button" role="tab"
                                        aria-controls="home-tab-pane" aria-selected="true">Our mission</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                                        data-bs-target="#profile-tab-pane" type="button" role="tab"
                                        aria-controls="profile-tab-pane" aria-selected="false">Our Vision</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="contact-tab" data-bs-toggle="tab"
                                        data-bs-target="#contact-tab-pane" type="button" role="tab"
                                        aria-controls="contact-tab-pane" aria-selected="false">Contact</button>
                                </li>

                            </ul>
                        </div>
                       
                        <div class="tabs-details">
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel"
                                    aria-labelledby="home-tab" tabindex="0">Aligned to our Corporate Philosophy, our
                                    mission
                                    is to ensure our customers, our employees and anyone engaging with AMB , experience
                                    Confidence, Comfort and Enjoyment.
                                </div>
                                <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel"
                                    aria-labelledby="profile-tab" tabindex="0">The AMB Logistic will continue to provide
                                    “confidence,” “comfort” and “enjoyment” while working with local communities to
                                    foster
                                    mutual development.</div>
                                <div class="tab-pane fade" id="contact-tab-pane" role="tabpanel"
                                    aria-labelledby="contact-tab" tabindex="0">...</div>
                            </div>
                        </div>
                    </div>


                </div>
                <div class="col-lg-5 col-12">
                    <div>
                        <img src="assets/images/banner-main2.png" class="img-fluid" />
                    </div>

                </div>
            </div>

        </div>
    </section> -->

<!-- contact-us -->
<section class="contact-section">
    <div class="container">
        <div class="row align-items-center justify-content-md-center  justify-content-between">
            <div class="col-lg-6">
                <div>
                    <div class="contact-content ml-30">

                        <h2 class="mb-0">We are the Future of Cargo & Logistics
                        </h2>

                    </div>
                </div>
                <div class="row align-items-center mt-5 ">
                    <div class="col-md-4 col-sm-4 col-6">
                        <div class="tj-icon-box3 text-center">
                            <i class="fa fa-user-circle-o" aria-hidden="true"></i>
                            <h6 class="title">Optimized Cost</h6>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-6">
                        <div class="tj-icon-box3 text-center">
                            <i class="fa fa-truck" aria-hidden="true"></i>
                            <h6 class="title">Delivery on Time</h6>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-6">
                        <div class="tj-icon-box3 text-center">
                            <i class="fa fa-handshake-o" aria-hidden="true"></i>
                            <h6 class="title">Safety &amp; Reliability</h6>
                        </div>
                    </div>

                </div>
            </div>

            <div class="col-lg-5 col-md-8 col-12">

                <div class="form-section"> 
                    <script>  
                        $(document).ready(function(){
                            //alert('hii');
                            $('#user_form').submit(function (e) {
                               // alert(form);
                               e.preventDefault();
                            var form_data = $('#user_form').serialize();
                                $.ajax({
                                method: "POST",
                                url: "mail.php",
                                data: form_data,
                                success: function(result){
                                    $('#result').html(result);
                                } 
                                });
                            }); 
                        })                         
                                
                    </script>                                 
                    <form id="user_form">
                        <input type="hidden" name="data_from" value="user">
                        <div class="row align-itmes-center justify-content-between ">
                            <div class="col-md-6 col-12">
                                <label class="custome-label" for="firstname">
                                    Enter your first name
                                </label>
                                <div class="form-group custome-group">

                                    <input type="text" name="f_name" class="form-control custome-control" id="firstname"
                                        placeholder="" require />
                                    <div class="input-icon">
                                        <i class="fa fa-address-card" aria-hidden="true"></i>
                                    </div>


                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <label class="custome-label" for="lastname">
                                    Enter your last Name
                                </label>
                                <div class="form-group custome-group">
                                    <input type="text" name="l_name" class="form-control custome-control" id="lastname" placeholder=""
                                        require />
                                    <div class="input-icon">
                                        <i class="fa fa-address-card" aria-hidden="true"></i>
                                    </div>


                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <label class="custome-label" for="phone">
                                    Enter your Contact number

                                </label>
                                <div class="form-group custome-group">

                                    <input type="tel" name="phone" id="phone" class="form-control custome-control" placeholder="" require />
                                    <div class="input-icon">
                                    <i class="fa fa-phone-square" aria-hidden="true"></i>

                                    </div>


                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <label class="custome-label" for="mail">
                                    Enter your email-id

                                </label>
                                <div class="form-group custome-group">

                                    <input type="email" id="mail" name="email" class="form-control custome-control" placeholder="" require />
                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>
                            </div>

                            <div class="col-12">
                                <label class="custome-label" for="message">
                                    Enter your message

                                </label>
                                <div class="form-group custome-group">
                                    <textarea class="form-control custome-control px-1"
                                        id="message" name="message" ></textarea>
                                </div>
                            </div>
                            <p class="text text-white" id="result"></p>
                            <div class="col-lg-7">
                                <div class="send-btn">
                                    <button type="submit" name="submit" class="custome-submit">
                                        Submit
                                    </button>
                                </div>

                            </div>
                        </div>

                    </form>

                </div>
            </div>

        </div>

    </div>

</section>
<!-- end-contact-us -->
<!-- faq-section -->
<section class="faq-section">

    <div class="container">
        <div class=" row align-items-center justify-content-center">
            <div class="col-lg-6 text-center">
                <div class="sub-heading">
                    <h2 class="heading-detail mx-2 mb-0">
                        <svg class="svg-left svg-right me-2" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" width="33" height="21" viewBox="0 0 33 21">
                            <defs>

                                <filter id="left-h-filterct_heading-36d6b53" x="-0.125" y="-0.094" width="32.406"
                                    height="12" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <filter id="left-h-filter-2ct_heading-36d6b53" x="-10" y="14.594" width="29.656"
                                    height="6.406" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <linearGradient id="left-h-grad1ct_heading-36d6b53" x1="0%" y1="0%" x2="100%" y2="0%">
                                    <stop offset="0%" style="stop-color: #0273bf;stop-opacity:1"></stop>
                                    <stop offset="100%" style="stop-color: #026eb8;stop-opacity:1"></stop>
                                </linearGradient>
                            </defs>
                            <g>
                                <g style="fill: none; filter: url(#left-h-filterct_heading-36d6b53)">
                                    <path id="left-h-pathct_heading-36d6b53" class="h-cls-1"
                                        d="M-0.117,8.9H27.036s5.078-3.073,0-6.517"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-pathct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                                <g style="fill: none; filter: url(#left-h-filter-2ct_heading-36d6b53)">
                                    <path id="left-h-bgct_heading-36d6b53" class="h-cls-2"
                                        d="M-9.991,14.594H17.352s5.114,3.027,0,6.422"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-bgct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                            </g>
                        </svg>HOW IT’S WORK<svg class="svg-left ms-2" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" width="33" height="21" viewBox="0 0 33 21">
                            <defs>
                                <style>
                                .h-cls-1,
                                .h-cls-2 {
                                    fill: none;
                                    stroke-width: 3px;
                                    fill-rule: evenodd;
                                }

                                .h-cls-1 {
                                    filter: url(#filter);
                                }

                                .h-cls-2 {
                                    filter: url(#filter-2);
                                }
                                </style>
                                <filter id="left-h-filterct_heading-36d6b53" x="-0.125" y="-0.094" width="32.406"
                                    height="12" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <filter id="left-h-filter-2ct_heading-36d6b53" x="-10" y="14.594" width="29.656"
                                    height="6.406" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <linearGradient id="left-h-grad1ct_heading-36d6b53" x1="0%" y1="0%" x2="100%" y2="0%">
                                    <stop offset="0%" style="stop-color: #0273bf;stop-opacity:1"></stop>
                                    <stop offset="100%" style="stop-color: #026eb8;stop-opacity:1"></stop>
                                </linearGradient>
                            </defs>
                            <g>
                                <g style="fill: none; filter: url(#left-h-filterct_heading-36d6b53)">
                                    <path id="left-h-pathct_heading-36d6b53" class="h-cls-1"
                                        d="M-0.117,8.9H27.036s5.078-3.073,0-6.517"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-pathct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                                <g style="fill: none; filter: url(#left-h-filter-2ct_heading-36d6b53)">
                                    <path id="left-h-bgct_heading-36d6b53" class="h-cls-2"
                                        d="M-9.991,14.594H17.352s5.114,3.027,0,6.422"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-bgct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                            </g>
                        </svg>
                    </h2>
                </div>
            </div>
            <div class="row align-items-center align-items-md-start justify-content-between   pt-sm-2 pt-md-3 pt-lg-5">
                <div class="col-lg-5 col-md-7 ">
                    <div class="slide-section">
                        <img src="assets/images/slider-4.jpg" class="img-fluid" alt="slider" />
                        <div class="faq-text">
                            <div class="check-section">
                                <span>
                                    <i class="fa fa-check" aria-hidden="true"></i>
                                </span>
                            </div>
                            <div class="check-detail">
                                <h6 class="title">Reliable &amp; Trustworthy</h6>
                                <p>Trage agile frameworks to provide a robust synopsis for high level overviews.</p>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-lg-6 col-md-12">


                    <section id="faq" class="faq">


                        <div class="fqa-detail">
                            <h2>
                                Frequently Asked Questions
                            </h2>

                        </div>
                        <div class="faq-list">
                            <ul>
                                <li>
                                    <i class="fa fa-question-circle icon-help" aria-hidden="true"></i> <a
                                        data-bs-toggle="collapse" class="collapse" data-bs-target="#faq-list-1">
                                        Why choose this? <i class="fa fa-sm fa-angle-down icon-show"
                                            aria-hidden="true"></i><i class="fa fa-sm fa-angle-up icon-close"></i></a>
                                    <div id="faq-list-1" class="collapse show" data-bs-parent=".faq-list">
                                        <p>
                                            They offers a host of logistic management services and supply chain . We
                                            provide innovative solutions with the best.
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <i class="fa fa-question-circle icon-help" aria-hidden="true"></i> <a
                                        data-bs-toggle="collapse" data-bs-target="#faq-list-2" class="collapsed">

                                        How would I know my fare charges & bill amount?
                                        <i class="fa fa-sm fa-angle-down icon-show" aria-hidden="true"></i><i
                                            class="fa fa-sm fa-angle-up icon-close"></i></a>
                                    <div id="faq-list-2" class="collapse" data-bs-parent=".faq-list">
                                        <p>
                                            Once our system receives your booking, you will be notified of the
                                            approximate distance that your goods will travel, and accordingly your
                                            bill amount will be calculated. With our fare calculator, we
                                            instantaneously give you the best rate online.
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <i class="fa fa-question-circle icon-help" aria-hidden="true"></i> <a
                                        data-bs-toggle="collapse" data-bs-target="#faq-list-3" class="collapsed">

                                        How will I receive my invoice?
                                        <i class="fa fa-sm fa-angle-down icon-show" aria-hidden="true"></i><i
                                            class="fa fa-sm fa-angle-up icon-close"></i></a>
                                    <div id="faq-list-3" class="collapse" data-bs-parent=".faq-list">
                                        <p>
                                            You will receive an auto-generated invoice on your registered e-mail ID
                                            once the consignment has been delivered.
                                        </p>
                                    </div>
                                </li>
                                <li>
                                    <i class="fa fa-question-circle icon-help" aria-hidden="true"></i> <a
                                        data-bs-toggle="collapse" data-bs-target="#faq-list-4" class="collapsed">


                                        Do you provide Parcel, bike, courier or car transport service?
                                        <i class="fa fa-sm fa-angle-down icon-show" aria-hidden="true"></i><i
                                            class="fa fa-sm fa-angle-up icon-close"></i></a>
                                    <div id="faq-list-4" class="collapse" data-bs-parent=".faq-list">
                                        <p>
                                            We only provide full truck transport services, we do not provide
                                            services for courier, parcels or car transportation.
                                        </p>
                                    </div>
                                </li>
                            </ul>


                        </div>
                    </section>

                </div>
            </div>

        </div>

    </div>
</section>
<!-- end-faq-section -->
<!-- footer-section -->
<?php
include("common/footer.php");

?>