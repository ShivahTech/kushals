<?php
include ("common/header.php");
?>
<section class="main-contact-sectiones">
    <div class="container">
        <div class="row align-item-center justify-content-center h-100hv">
            <div class="col-lg-12 text-center">
                <div class="contact-detail">

                    <ul>
                        <li>
                            <a class="banner-links" href="index.php">HOME</a>
                        </li>
                        <li>
                            <a class="banner-links right-arrow mx-2" href="#"> <i class="fa fa-angle-double-right"
                                    aria-hidden="true"></i></a>
                        </li>
                        <li>
                            <a class="banner-links" href="#">CONTACT</a>
                        </li>
                    </ul>
                </div>

            </div>

        </div>

    </div>

</section>
<!-- banner-section -->
<section class="center-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-12 text-center">
                <div class="features-details ml-30">
                    <span>MAKE REQUEST</span>
                    <h2>Get In Touch</h2>
                </div>
            </div>

        </div>
        <div class="row  justify-content-between custome-contact">
            <div class="col-lg-6">
                <div class="map-sectio">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2938.7373711849323!2d-83.15239702487368!3d42.56086922239279!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8824c43dee9d8477%3A0x34a4364c808ca1b8!2s101%20W%20Big%20Beaver%20Rd%20Suit%201400%2C%20Troy%2C%20MI%2048084%2C%20USA!5e0!3m2!1sen!2sin!4v1696829470598!5m2!1sen!2sin"
                        width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="contact-form">
                <script>  
                        $(document).ready(function(){
                            //alert('hii');
                            $('#contact_form').submit(function (e) {
                               // alert(form);
                               e.preventDefault();
                            var form_data = $('#contact_form').serialize();
                                $.ajax({
                                method: "POST",
                                url: "mail.php",
                                data: form_data,
                                success: function(result){
                                    $('#result').html(result);
                                } 
                                });
                            }); 
                        })                         
                </script>              
                
                    <form id="contact_form">
                    <input type="hidden" name="data_from" value="contact">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <div class="form-group group-form">
                                    <label for="name"> Enter Your Name</label>
                                    <input class="form-control contact-from" id="name" name="name" placeholder="" tpye="text" require />
                                </div>

                            </div>
                            <div class="col-12">
                                <div class="form-group group-form">
                                    <label for="email"> Enter Your Email-id</label>
                                    <input class="form-control contact-from" id="email" name="email" tpye="email" require />
                                </div>

                            </div>
                            <div class="col-12">
                                <div class="form-group group-form">
                                    <label for="message"> Enter Your Message</label>
                                    <textarea class="form-control contact-form"
                                      id="message" name="message"></textarea>
                                </div>

                            </div>
                            <p class="text" id="result"></p>
                            <div class="col-lg-7">
                                <div class="send-btn">
                                    <button type="submit" name="submit" class="custome-submit">
                                        Submit
                                    </button>
                                </div>

                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- last-section -->
<section class="location-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-4 col-md-4 col-12 col-sm-6  mt-4 mt-md-0">
                <div class="address-section">
                    <a href="tel:+1 888 538 6433" class="call-link">
                        <div class="call-section">
                            <i class="fa fa-phone" aria-hidden="true"></i>

                        </div>
                        <h4>
                            Phone Number

                        </h4>
                        <p>
                            +1 888 538 6433
                        </p>
                    </a>
                </div>

            </div>
            <div class="col-lg-4 col-md-4 col-12 col-sm-6 mt-4 mt-md-0">
                <div class="address-section">
                    <a href="tel:+1 888 538 6433" class="call-link">
                        <div class="call-section">
                            <i class="fa fa-envelope" aria-hidden="true"></i>

                        </div>
                        <h4>
                            Mail

                        </h4>
                        <p>
                            info@amblogistic.us

                        </p>
                    </a>
                </div>

            </div>
            <div class="col-lg-4 col-md-4 col-12 col-sm-6 mt-4 mt-md-0">
                <div class="address-section">
                    <a href="tel:+1 888 538 6433" class="call-link">
                        <div class="call-section">
                            <i class="fa fa-location-arrow" aria-hidden="true"></i>


                        </div>
                        <h4>
                            Address


                        </h4>
                        <p>
                            101 W Big Beaver Rd Suite 1400 , Troy MI 48084 </p>
                    </a>
                </div>

            </div>
        </div>

    </div>

</section>
<?php
include ("common/footer.php");
?>