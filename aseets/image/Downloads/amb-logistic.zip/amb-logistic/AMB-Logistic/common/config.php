<?php 
    //database connect

    $conn = mysqli_connect('localhost','root','','amb-logistic');
    if(!$conn){
        echo "Error: Database Connection Failed";
    }
?>