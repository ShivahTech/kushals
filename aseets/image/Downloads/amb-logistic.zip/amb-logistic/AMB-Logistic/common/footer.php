    <!-- footer-section -->
    <footer class="main-footer-section">
        <div class="container">
            <div class="row justify-content-between pb-3 ">
                <div class="col-lg-4 col-md-7">
                    <div class="footer-logo">
                        <a class="" href="#">
                            <img class="img-fluid" src="assets/images/amb.svg" />
                        </a>
                    </div>
                    <div class="logo-detail">
                        <p>
                            AMB Logistic operate a variety of high quality services worldwide, whether for
                            Import, Export, Triangle or Domestic. We offer a full suite of services by
                            Air, Ocean, Road & Rail in order to provide you the optimum balance of
                            time and money.
                        </p>

                    </div>

                </div>
                <div class="col-lg-3 col-md-5">
                    <div class="quick-link">
                        <h2>
                            Quick Link
                        </h2>
                        <ul>
                            <li>
                                <a class="footer-link" href="">
                                    About

                                </a>
                            </li>
                            <li>
                                <a class="footer-link" href="">
                                    Services

                                </a>
                            </li>
                            <li>
                                <a class="footer-link" href="">
                                    Contact
                                </a>
                            </li>
                        </ul>

                    </div>

                </div>
                <div class="col-lg-4">
                    <div class="our-gallery quick-link">
                        <h2>
                            Our Projects
                        </h2>
                    </div>
                    <div class="row align-items-cener gallery-section">
                        <div class="col-4">
                            <div class="link-footer">
                                <a href="#" class="gallery-link">
                                    <img src="assets/images/icone-1.jpg" class="">

                                </a>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="link-footer">
                                <a href="#" class="gallery-link">
                                    <img src="assets/images/icone-2.jpg" class="">

                                </a>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="link-footer">

                                <a href="#" class="gallery-link">
                                    <img src="assets/images/icone-3.jpg" class="">

                                </a>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="link-footer">
                                <a href="#" class="gallery-link">
                                    <img src="assets/images/icone-4.jpg" class="">
                                </a>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="link-footer">
                                <a href="#" class="gallery-link">
                                    <img src="assets/images/icone-5.jpg" class="">
                                </a>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="link-footer">
                                <a href="#" class="gallery-link">
                                    <img src="assets/images/icone-6.jpg" class="">
                                </a>
                            </div>
                        </div>
                        
                    </div>
                    <div class="gallery-section">






                    </div>


                </div>

            </div>

        </div>
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-lg-12 text-center">
                    <div>
                        <p class="copy-detail">
                        © Copyrights 2021 AMB Logistic. All rights reserved.
                        </p>
                    </div>

                </div>

            </div>

        </div>
    </footer>
</main>
    <!-- footer-section -->
    <!-- jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-migrate-3.4.1.min.js"
        integrity="sha256-UnTxHm+zKuDPLfufgEMnKGXDl6fEIjtM+n1Q6lL73ok=" crossorigin="anonymous"></script>
    <!-- js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
    </script>
    <!-- aos-animation -->

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <!-- custome-js -->
    <script src="assets/js/custome.js"></script>
</body>

</html>