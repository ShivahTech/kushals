<?php
include("common/header.php");

?>
<!-- about-section-banner -->
<section class="about-section">
    <div class="container">
        <div class="row align-items-center vh-100">
            <div class="col-lg-7">
                <div class="about-detail">
                    <h2 class="text-detail">
                 Services
                    </h2>
                    <p>
                    AMB Logistic operates a variety of high quality services worldwide whether for import, export, triangle or domestic. We offer a full suite of services by Air, Ocean, Road & Rail in order to provide you the optimum balance of time and money. AMB Logistic provides contract warehousing and distribution services from modern facilities and sophisticated warehouse management systems to provide integrated real-time inventory management. AMB operate a variety of high quality services worldwide, whether for Import, Export, Triangle
                        or Domestic. We offer a full suite of services by Air, Ocean, Road & Rail in order to provide
                        you the optimum balance of time and money.
                    </p>
                    <!-- <div class="banner-btn  about-btn">
                        <a class="banner-link" href="#">
                            Services <i class="fa fa-angle-double-right ms-2" aria-hidden="true"></i>

                        </a>
                    </div> -->
                </div>
            </div>
        </div>
    </div>
</section>
<!--end about-section-banner -->
<!-- our -->
<section class="padding-top services-section">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-lg-6 text-center">
                <div class="sub-heading">
                    <h2 class="heading-detail mx-2">
                        <svg class="svg-left svg-right me-2" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" width="33" height="21" viewBox="0 0 33 21">
                            <defs>

                                <filter id="left-h-filterct_heading-36d6b53" x="-0.125" y="-0.094" width="32.406"
                                    height="12" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <filter id="left-h-filter-2ct_heading-36d6b53" x="-10" y="14.594" width="29.656"
                                    height="6.406" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <linearGradient id="left-h-grad1ct_heading-36d6b53" x1="0%" y1="0%" x2="100%" y2="0%">
                                    <stop offset="0%" style="stop-color: #0273bf;stop-opacity:1"></stop>
                                    <stop offset="100%" style="stop-color: #026eb8;stop-opacity:1"></stop>
                                </linearGradient>
                            </defs>
                            <g>
                                <g style="fill: none; filter: url(#left-h-filterct_heading-36d6b53)">
                                    <path id="left-h-pathct_heading-36d6b53" class="h-cls-1"
                                        d="M-0.117,8.9H27.036s5.078-3.073,0-6.517"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-pathct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                                <g style="fill: none; filter: url(#left-h-filter-2ct_heading-36d6b53)">
                                    <path id="left-h-bgct_heading-36d6b53" class="h-cls-2"
                                        d="M-9.991,14.594H17.352s5.114,3.027,0,6.422"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-bgct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                            </g>
                        </svg> Our Services<svg class="svg-left ms-2" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" width="33" height="21" viewBox="0 0 33 21">
                            <defs>
                                <style>
                                .h-cls-1,
                                .h-cls-2 {
                                    fill: none;
                                    stroke-width: 3px;
                                    fill-rule: evenodd;
                                }

                                .h-cls-1 {
                                    filter: url(#filter);
                                }

                                .h-cls-2 {
                                    filter: url(#filter-2);
                                }
                                </style>
                                <filter id="left-h-filterct_heading-36d6b53" x="-0.125" y="-0.094" width="32.406"
                                    height="12" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <filter id="left-h-filter-2ct_heading-36d6b53" x="-10" y="14.594" width="29.656"
                                    height="6.406" filterUnits="userSpaceOnUse">
                                    <feFlood result="flood"></feFlood>
                                    <feComposite result="composite" operator="in" in2="SourceGraphic"></feComposite>
                                    <feBlend result="blend" in2="SourceGraphic"></feBlend>
                                </filter>
                                <linearGradient id="left-h-grad1ct_heading-36d6b53" x1="0%" y1="0%" x2="100%" y2="0%">
                                    <stop offset="0%" style="stop-color: #0273bf;stop-opacity:1"></stop>
                                    <stop offset="100%" style="stop-color: #026eb8;stop-opacity:1"></stop>
                                </linearGradient>
                            </defs>
                            <g>
                                <g style="fill: none; filter: url(#left-h-filterct_heading-36d6b53)">
                                    <path id="left-h-pathct_heading-36d6b53" class="h-cls-1"
                                        d="M-0.117,8.9H27.036s5.078-3.073,0-6.517"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-pathct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                                <g style="fill: none; filter: url(#left-h-filter-2ct_heading-36d6b53)">
                                    <path id="left-h-bgct_heading-36d6b53" class="h-cls-2"
                                        d="M-9.991,14.594H17.352s5.114,3.027,0,6.422"
                                        style="stroke: inherit; filter: none;"></path>
                                </g>
                                <use xlink:href="#left-h-bgct_heading-36d6b53"
                                    style="stroke: url(#left-h-grad1ct_heading-36d6b53); filter: none; fill: none">
                                </use>
                            </g>
                        </svg>
                    </h2>
                </div>
            </div>



        </div>
        <div class="row align-items-center justify-content-between ">
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="">
                                        <img src="assets/images/ltl.png" class="img-fluid" />

                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    LTL</h4>
                                <div class="feature-details">
                                    Less than load is a shipping service for relatively small loads or quantities of
                                    freight - Between 150 and 15,000 pounds.


                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                    Less than load
                                     </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="">
                                        <img src="assets/images/ftl.png" class="img-fluid" />

                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    FTL</h4>
                                <div class="feature-details">
                                    In case you require a full truck to get your load shipped, FTL(Full Truckload) takes
                                    advantage of the entire volume of the vehicle which can weigh 20,000 pounds or more.


                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                Full Truckload  </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="">
                                        <img src="assets/images/ftb.png" class="img-fluid" />

                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    FLAT BED</h4>
                                <div class="feature-details">
                                    It has a flat carrier attached to it for carrying cargo wherein the flat trailer
                                    allows cargo to be loaded from the top as well as from the side. It can transport
                                    all kinds of loads.

                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                     FLAT BED
                                  </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="row align-items-center justify-content-between set-margin">
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="#">
                                        <img src="assets/images/ref.png" class="img-fluid" />
                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    REFRIGERATED
                                </h4>
                                <div class="feature-details">
                                    (also referred to as “reefer”) is a freight shipping method that specializes in the
                                    transportation of foods and products that require a temperature-controlled means of
                                    transport.




                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                     REFRIGERATED </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="#">
                                        <img src="assets/images/dry.png" class="img-fluid" />

                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    DRY FREIGHT
                                </h4>
                                <div class="feature-details">
                                    A dry van is a type of semi-trailer that’s fully enclosed to protect shipments from
                                    outside elements. They are used in transporting many different items, as they can
                                    carry large shipments up to 45,000 pounds.



                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                DRY FREIGHT
                                 </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="#">
                                        <img src="assets/images/van.png" class="img-fluid" />
                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    PADDED VANS

                                </h4>
                                <div class="feature-details">
                                    When transit of goods needs to be handled with extra care and sensitivity, padded
                                    van service is the solution of choice.



                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                   PADDED VANS </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="row align-items-center justify-content-between set-margins">
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="#">
                                        <img src="assets/images/strips.png" class="img-fluid" />

                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    STRAPS

                                </h4>
                                <div class="feature-details">
                                    Straps play an important role in securing cargo and holding down equipment while
                                    being transported. It is a popular method of holding in place equipment and cargo of
                                    different weights, sizes, and shapes.



                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                STRAPS </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="#">
                                        <img src="assets/images/trc.png" class="img-fluid" />

                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    BLANKET WRAP

                                </h4>
                                <div class="feature-details">
                                    Blanket wrapped cargo is commonly transported on air ride suspension trailers,
                                    providing an extra shock absorbing buffer and an extra degree of care for fragile
                                    and/or sensitive goods.

                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                BLANKET WRAP
 </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="#">
                                        <img src="assets/images/sbt.png" class="img-fluid" />
                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    STAKE BEDS
                                </h4>
                                <div class="feature-details">
                                    Stake bed trucks are flatbeds with a stake framework. It can haul cargo weighing up
                                    to 10,000 lbs and even more.


                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                STAKE BEDS
                                 </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="row align-items-center justify-content-between set-margins">
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="#">
                                        <img src="assets/images/ship.png" class="img-fluid" />

                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    OCEAN FREIGHT

                                </h4>
                                <div class="feature-details">
                                    Ocean freight is the method of transporting often large loads of goods by sea –
                                    putting cargo in large containers which are loaded onto vessels.




                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                OCEAN FREIGHT
                                 </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="#">
                                        <img src="assets/images/air.png" class="img-fluid" />

                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    AIR FREIGHT


                                </h4>
                                <div class="feature-details">
                                    Goods delivered by air have the advantage of high-speed, time-sensitive shipping to
                                    any location in the world, which is extremely beneficial to small and mid-sized
                                    businesses.



                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                AIR FREIGHT
                                </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon">
                                        <img src="assets/images/team.png" class="img-fluid" />
                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    TEAM DRIVERS


                                </h4>
                                <div class="feature-details">
                                    Team driving is all about keeping the truck in motion and the goods moving. This is
                                    when two drivers work together to transport freight in order to make hauling more
                                    efficient.




                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                TEAM DRIVERS
                                 </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="row align-items-center justify-content-between set-margins">

            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="services-section">
                    <div class="feature-current-item-style1 ">
                        <div class="feature-inner">
                            <div class="feature-content">
                                <div class="feature-icon">
                                    <a class="icon" href="#">
                                        <img src="assets/images/ld.png" class="img-fluid" />
                                    </a>
                                </div>
                                <h4 class="feature-title ">
                                    LOCAL DELIVERIES



                                </h4>
                                <div class="feature-details">
                                    These trucks include commercial trucks, used to deliver cargo and freight ( for e.g.
                                    courier services, delivery trucks, box trucks moving freight, waste haulers, dump
                                    trucks, concrete mixers).
                                </div>
                            </div>
                            <div class="feature-btn">
                                <a href="#">
                                LOCAL DELIVERIES
                                 </a>
                            </div>
                            <div class="feature-thumb-wrapper">
                                <div class="feature-thumb"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>

</section>
<?php
include("common/footer.php");

?>