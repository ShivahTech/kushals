<?php
include("common/header.php");
?>
<!-- about-section-banner -->
<section class="about-section">
    <div class="container">
        <div class="row align-items-center vh-100">
            <div class="col-lg-6">
                <div class="about-detail">
                    <h2 class="text-detail">
                        About
                    </h2>
                    <p>
                        AMB Logistic operate a variety of high quality services worldwide, whether for Import, Export, Triangle
                        or Domestic. We offer a full suite of services by Air, Ocean, Road & Rail in order to provide
                        you the optimum balance of time and money.
                    </p>
                    <div class="banner-btn  about-btn">
                        <a class="banner-link" href="#">
                            Services <i class="fa fa-angle-double-right ms-2" aria-hidden="true"></i>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--end about-section-banner -->
<!--about-company  -->
<section class="about-padding">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-6 col-12">
                <div class="company-images-section">
                    <div class="first-section">
                        <img src="assets/images/services.jpg" class="img-fluid" />
                    </div>
                    <div class="inner-section"></div>
                    <div class="last-section ">

                        <img src="assets/images/offer-img.jpg" class="img-fluid" />

                    </div>
                </div>

            </div>
            <div class="col-lg-6 col-md-6 col-12">
                <div class="company-detail">
                    <div class="about-content ml-30">
                        <span>About Us</span>
                        <h2>WE ARE AMB Logistic</h2>
                        <p class="mb-4">
                            AMB Logistic provide contract warehousing and distribution services from modern facilities and
                            sophisticated warehouse management systems to provide integrated real-time inventory
                            management.</p>
                        <p>
                            AMB Logistic operates a variety of high quality services worldwide whether for import, export,
                            triangle or domestic. We offer a full suite of services by Air, Ocean, Road & Rail in order
                            to provide you the optimum balance of time and money. AMB Logistic provides contract warehousing and
                            distribution services from modern facilities and sophisticated warehouse management systems
                            to provide integrated real-time inventory management.
                        </p>
                    </div>

                </div>
                <div class="progresbar-section">
                    <div class="skill">
                        <p>Transport</p>
                        <div class="skill-bar skill1 wow slideInLeft  animated"
                            style="visibility: visible; animation-name: slideInLeft;">
                            <span class="skill-count1">95%</span>
                        </div>
                    </div>
                </div>
                <div class="ceo">
                    <div class="d-flex align-items-center justify-content-end ">
                        <div class="founder-imgfounder-imgfounder-img">
                            <img src="assets/images/ceo.jfif" class="img-fluid" />
                        </div>
                        <div class="founder-detail">
                            <h4>
                                Harvinder Paul Singh

                            </h4>
                            <p>
                                Founder & CEO

                            </p>
                        </div>

                    </div>

                </div>
            </div>
        </div>

    </div>

</section>
<!-- why chooes-us -->
<section class="chooes-section">
    <div class="container">
        <div class="row align-items-center justify-center">
            <div class="col-lg-12 text-center">
                <div class="features-details ml-30">
                    <span>FEATURES</span>
                    <h2>WHY CHOOSE US</h2>

                </div>
            </div>

        </div>
        <div class="row align-items-center ">
            <div class="col-lg-4 col-md-6 col-12">

                <div class="services-detail">
                    <div class="service-item-current-style3">
                        <div class="inner-box">
                            <div class="image">
                                <a href="#">
                                    <img class="img-fluid" src="assets/images/ltl.jpg"
                                        class="img-fullwidth wp-post-image" alt="" decoding="async"
                                        sizes="(max-width: 1920px) 100vw, 1920px"> </a>
                            </div>
                            <div class="content-box">
                                <div class="icon-box">
                                    <div class="icon">
                                        <img src="assets/images/delivery-truck.png" class="img-fluid" />
                                    </div>
                                </div>
                                <h4 class="title service-title">
                                    <a href="#" class="ltl-detail">
                                        24/7 SUPPORT
                                    </a>
                                </h4>
                                <div class="inner">
                                    <div class="excerpt service-details">
                                        AMB Logistic will strive to draw on our group’s management resources, further
                                        refine our products and services, and improve our corporate value. In order to
                                        inform as many people as possible of our vision for the future, we came up with
                                        a new corporate message: “Connecting your dreams”</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-lg-4 col-md-6 col-12">
                <div class="services-detail">
                    <div class="service-item-current-style3">
                        <div class="inner-box">
                            <div class="image">
                                <a href="#">
                                    <img class="img-fluid"
                                        src="https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10.jpg"
                                        class="img-fullwidth wp-post-image" alt="" decoding="async"
                                        srcset="https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10.jpg 1920w, https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10-300x200.jpg 300w, https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10-1024x683.jpg 1024w, https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10-768x512.jpg 768w, https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10-1536x1024.jpg 1536w, https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10-672x448.jpg 672w, https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10-600x400.jpg 600w"
                                        sizes="(max-width: 1920px) 100vw, 1920px"> </a>
                            </div>
                            <div class="content-box">
                                <div class="icon-box">
                                    <div class="icon"><img src="assets/images/delivery-truck.png" class="img-fluid" />
                                    </div>
                                </div>
                                <h4 class="title service-title">
                                    <a href="#" class="ltl-detail">ON TIME DELIVERY</a>
                                </h4>
                                <div class="inner">
                                    <div class="excerpt service-details">
                                        We provide services connected with all aspects of people’s daily lives, and must
                                        behave as a community planning company whose goal is to create a richer future
                                        for all. -</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-lg-4 col-md-6 col-12">
                <div class="services-detail">
                    <div class="service-item-current-style3">
                        <div class="inner-box">
                            <div class="image">
                                <a href="#">
                                    <img class="img-fluid"
                                        src="https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10.jpg"
                                        class="img-fullwidth wp-post-image" alt="" decoding="async"
                                        srcset="https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10.jpg 1920w, https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10-300x200.jpg 300w, https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10-1024x683.jpg 1024w, https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10-768x512.jpg 768w, https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10-1536x1024.jpg 1536w, https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10-672x448.jpg 672w, https://kodesolution.com/2023/tranxpress/wp-content/uploads/2022/10/bg10-600x400.jpg 600w"
                                        sizes="(max-width: 1920px) 100vw, 1920px"> </a>
                            </div>
                            <div class="content-box">
                                <div class="icon-box">
                                    <div class="icon"><img src="assets/images/delivery-truck.png" class="img-fluid" />
                                    </div>
                                </div>
                                <h4 class="title service-title">
                                    <a href="#" class="ltl-detail">GLOBAL SERVICE
                                    </a>
                                </h4>
                                <div class="inner">
                                    <div class="excerpt service-details">
                                        We aspire to provide customers and local communities with innovative products
                                        and services that are filled with compassion. We hope to share the dreams and
                                        future aspirations of people from all walks of life, and to grow together while
                                        realizing these dreams.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


        </div>

    </div>

</section>
<!--  -->
<!-- REQUEST A FREE QUOTE -->
<section class="quote-section">
    <div class="container">
        <div class="row  justify-content-center">
            <div class="col-lg-4">
                <div>
                    <div class="contact-content ml-30">

                        <h2 class="mb-0">REQUEST A FREE QUOTE
                        </h2>

                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="request-section">
                    
                <script>  
                    $(document).ready(function(){
                        $('#customer_form').submit(function(e){
                            e.preventDefault();
                            var form = $('#customer_form').serialize();
                            $.ajax({
                            method: "POST",
                            url: "mail.php",
                            data: form,
                            success: function(result){
                                console.log(result);
                                $('#result').html(result);
                            } 
                            });
                        }); 
                    })                         
                            
                </script> 
                            
                    <form class="request-from" id="customer_form" >
                    <input type="hidden" name="data_from" value="customer">
                        <div class="row align-items-center">


                            <div class="col-lg-4 col-sm-6 col-12 ">

                                <div class="form-group custome-group group-input">

                                    <input type="text" id="name" name="name" class="form-group form-control" placeholder="Enter your name" require />

                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>

                            </div>

                            <div class="col-lg-4 col-sm-6 col-12">

                                <div class="form-group custome-group group-input">

                                    <input type="text" id="email" name="email" class="form-group form-control" placeholder="Enter your email-id" require />

                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>

                            </div>

                            <div class="col-lg-4 col-sm-6 col-12">

                                <div class="form-group custome-group group-input">

                                    <input type="text" id="number" name="number" class="form-group form-control" placeholder="Enter your Number" require />

                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>

                            </div>

                            <div class="col-lg-4 col-sm-6 col-12">

                                <div class="form-group custome-group group-input">

                                    <input type="text" name="p_city" class="form-group form-control" placeholder=" PickUp City" require />

                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>

                            </div>

                            <div class="col-lg-4 col-sm-6 col-12 ">

                                <div class="form-group custome-group group-input">

                                    <select class="form-select" name="p_state" aria-label="Default select example">
                                        <option selected> PickUp State</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                    </select>

                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>

                            </div>

                            <div class="col-lg-4 col-sm-6 col-12">

                                <div class="form-group custome-group group-input">

                                    <input type="text" name="p_zip" class="form-group form-control" placeholder=" Pickup Zip /Postal" require />

                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>

                            </div>

                            <div class="col-lg-4 col-sm-6 col-12">

                                <div class="form-group custome-group group-input">

                                    <input type="text" name="d_city" class="form-group form-control" placeholder=" Delivery City" require />

                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>

                            </div>

                            <div class="col-lg-4 col-sm-6 col-12">

                                <div class="form-group custome-group group-input">

                                    <select class="form-select" name="d_state" aria-label="Default select example">
                                        <option selected> Delivery State</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                    </select>


                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>

                            </div>

                            <div class="col-lg-4 col-sm-6 col-12">

                                <div class="form-group custome-group group-input">

                                    <input type="text" name="d_zip" class="form-group form-control" placeholder=" Delivery Zip/Postal" require />

                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>

                            </div>
                            <!-- <div class="col-lg-4">

                                <div class="form-group custome-group group-input">

                                    <input type="text" class="form-group" placeholder="Enter your Commodity" require />

                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>

                            </div>
                            <div class="col-lg-4">

                                <div class="form-group custome-group group-input">

                                    <input type="text" class="form-group" placeholder=" Total Weight" require />

                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>

                            </div>
                            <div class="col-lg-4">

                                <div class="form-group custome-group group-input">

                                    <input type="text" class="form-group" placeholder="Enter your Temperature"
                                        require />

                                    <div class="input-icon">
                                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                    </div>


                                </div>

                            </div> -->
                            <p class="text" id="result"></p>
                            <div class="col-lg-7">
                                <div class="send-btn">
                                    <button type="submit" name="submit" class="custome-submit">
                                        Submit
                                    </button>
                                </div>

                            </div>
                        </div>
                </div>
                </form>
            </div>

        </div>

    </div>

    </div>
</section>
<!-- REQUEST A FREE QUOTE-end -->


<!-- mission-section -->
<section class="mission-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-4 col-md-6 col-12">
                <div class="vissionsection">
                 <div class="bully-banner">
                 <div class="bully-section">
                      <i class="fa fa-globe" aria-hidden="true"></i>

                    </div>
                 </div>
                    <div class="vission-detail">
                        <h3>
                            OUR <span class="mission-detail">
                                MISSION
                            </span>
                        </h3>
                        <p>
                            Aligned to our Corporate Philosophy, our mission is to ensure our customers, our employees
                            and anyone engaging with AMB Logistic, experience Confidence, Comfort and Enjoyment.


                        </p>
                    </div>
                    <div class="end-section">
                    <div class="value-section">
                    <i class="fa fa-globe" aria-hidden="true"></i>
                    </div>
                    </div>
                </div>

            </div>
            <div class="col-lg-4 col-md-6 col-12">
                <div class="vissionsection">
                    <div class="vission-bnner">
                    <div class="bully-section section-a">
                    <i class="fa fa-bullseye" aria-hidden="true"></i>

                    </div>
                    </div>
                    <div class="vission-detail">
                        <h3>
                            OUR <span class="vission">
                                VISION
                            </span>
                        </h3>
                        <p>
                        The AMB Logistic will continue to provide “confidence,” “comfort” and “enjoyment” while working with local communities to foster mutual development.



                        </p>
                    </div>
<div class="end-section">
<div class="value-section">
                    <i class="fa fa-bullseye" aria-hidden="true"></i>


                    </div>
</div>
                </div>

            </div>
            <div class="col-lg-4 col-md-6 col-12 text-md-center my-md-0 mx-md-auto">
                <div class="vissionsection">
                    <div class="bully-banner">
                    <div class="bully-section section-b">
                    <i class="fa fa-diamond" aria-hidden="true"></i>

                    </div>

                    </div>
                    <div class="vission-detail" >
                        <h3>
                            OUR <span class="value">
                                VALUE
                            </span>
                        </h3>
                        <p>
                            Aligned to our Corporate Philosophy, our mission is to ensure our customers, our employees
                            and anyone engaging with AMB Logistic , experience Confidence, Comfort and Enjoyment.


                        </p>
                    </div>
                    <div class="end-section">
                    <div class="value-section">
                    <i class="fa fa-diamond" aria-hidden="true"></i>

                    </div>
                    </div>
                </div>

            </div>
        </div>

    </div>

</section>
<!-- end-mission-section -->
<?php
 include("common/footer.php");
?>