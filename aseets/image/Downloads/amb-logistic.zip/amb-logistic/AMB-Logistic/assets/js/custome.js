// 
setTimeout(function(){
  $("#loader").fadeOut();  
}, 1000);
//  on scroll header fixed
$(window).scroll(function() {
    if ($(this).scrollTop() > 1){  
        $('header').addClass("sticky");
      }
      else{
        $('header').removeClass("sticky");
      }
    });
  
    // click toggle close
    $('.nav_link_a').on('click', function(){
      $('.navbar-collapse').collapse('hide');
      });
  

      // nav-tabs-pills
      