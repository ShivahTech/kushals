<?php

$config = [
	'name' => __('Bookmark', 'rishi'),
	'visibilityKey' => 'header_hide_bookmark',
];