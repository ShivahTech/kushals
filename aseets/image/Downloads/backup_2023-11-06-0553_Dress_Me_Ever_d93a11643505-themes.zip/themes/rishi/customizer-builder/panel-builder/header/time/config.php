<?php
$config = [
	'name'              => __('Time', 'rishi'),
	'typography_keys'   => ['headerTimeFont'],
	'visibilityKey'     => 'header_hide_time',
	// 'selective_refresh' => ['header_time_ed_icon'],
];
