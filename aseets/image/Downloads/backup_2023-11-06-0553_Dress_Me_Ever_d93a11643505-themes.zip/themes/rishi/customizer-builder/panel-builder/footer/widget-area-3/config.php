<?php

$config = [
    'name' => __('Widget 3', 'rishi'),
    'visibilityKey' => 'footer_hide_widget_three',
    // 'clone' => true,
];
