<?php

$config = [
    'name' => __('Widget 6', 'rishi'),
    'visibilityKey' => 'footer_hide_widget_six',
    // 'clone' => true,
];
