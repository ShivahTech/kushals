<?php

$config = [
    'name' => __('Widget 5', 'rishi'),
    'visibilityKey' => 'footer_hide_widget_five',
    // 'clone' => true,
];
