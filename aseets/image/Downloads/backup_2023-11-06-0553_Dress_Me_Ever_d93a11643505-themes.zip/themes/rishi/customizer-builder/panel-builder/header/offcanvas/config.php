<?php

$config = [
	'name' => __('Offcanvas', 'rishi')
];
